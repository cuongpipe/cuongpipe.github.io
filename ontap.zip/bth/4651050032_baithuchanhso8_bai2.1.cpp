#include <iostream>
#include <string>
using namespace std;

struct Student {
    string name;
    float gpa;
};

void siftDown(Student arr[], int i, int n)
{
    int maxIndex = i;
    int left = 2*i + 1;
    int right = 2*i + 2;
    if (left < n && arr[left].gpa > arr[maxIndex].gpa)
        maxIndex = left;
    if (right < n && arr[right].gpa > arr[maxIndex].gpa)
        maxIndex = right;
    if (i != maxIndex)
    {
        swap(arr[i], arr[maxIndex]);
        siftDown(arr, maxIndex, n);
    }
}

void heapSort(Student arr[], int n)
{
    for (int i = n/2 - 1; i >= 0; i--)
        siftDown(arr, i, n);

    for (int i = n-1; i >= 0; i--)
    {
        swap(arr[0], arr[i]);
        siftDown(arr, 0, i);
    }
}

int main()
{
    Student arr[] = { {"Nam", 3.2}, {"Binh", 2.8}, {"Chau", 3.6}, {"Dung", 3.1} };
    int n = 4;

    heapSort(arr, n);

    cout << "Diem trung binh giam dan:" << endl;
    for (int i = 0; i < n; ++i)
        cout << arr[i].name << " " << arr[i].gpa << endl;
    return 0;
}
