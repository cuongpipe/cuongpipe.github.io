#include <iostream>
#include <fstream>
#include <cstring>
#include <queue>
using namespace std;
#define MAX_VERTICES 100


struct AdjMatrixGraph {
	int numVertices;
	int adjMatrix[MAX_VERTICES][MAX_VERTICES];
};

//a) Hàm đọc tệp dữ liệu đồ thị:
void readGraphFromFile(string fileName, AdjMatrixGraph &graph) {
// Open the file for reading
	ifstream file(fileName);
// Read the number of vertices from the file
	file >> graph.numVertices;
// Read adjacency matrix from file
	for (int i = 0; i < graph.numVertices; i++) {
		for (int j = 0; j < graph.numVertices; j++) {
			file >> graph.adjMatrix[i][j];
		}
	}
// Close the file
	file.close();
}

//b) Hàm in đồ thị biểu diễn bằng ma trận kề:
void printGraph(AdjMatrixGraph graph) {
	cout << "Num of vertices: " << graph.numVertices << endl;
	for (int i = 0; i < graph.numVertices; i++) {
		for (int j = 0; j < graph.numVertices; j++) {
			cout << graph.adjMatrix[i][j] << " ";
		}
		cout << endl;
	}
	cout << endl;
}

//c) Hàm duyệt đồ thị theo chiều sâu:
void DFS(const AdjMatrixGraph& graph, int vertex, bool visited[]) {
// Mark the current vertex as visited
	visited[vertex] = true;
	cout << vertex << " ";
// Recur for all the vertices adjacent to this vertex
	for (int i = 0; i < graph.numVertices; i++) {
		if (graph.adjMatrix[vertex][i] != 0 && !visited[i]) {
			DFS(graph, i, visited);
		}
	}
}

//(d) Duyệt đồ thị có trọng số từ 1 đỉnh bất kỳ

//(e) Duyệt hết tất cả các đỉnh với đồ thị không liên thông
void traverseGraph(AdjMatrixGraph g) {
	bool visited[MAX_VERTICES];
	memset(visited, false, sizeof(visited));
	for (int i = 0; i < g.numVertices; i++) {
		if (!visited[i]) {
			DFS(g, i, visited);
		}
	}
}

//(f) Duyệt theo chiều rộng đã cho:
void BFS(const AdjMatrixGraph& graph, int vertex) {
// Create a queue for BFS
	queue<int> queue;
// Create a boolean array to track visited vertices
	bool visited[MAX_VERTICES];
	memset(visited, false, sizeof(visited));
// Mark the current vertex as visited and enqueue it
	visited[vertex] = true;
	queue.push(vertex);
// Iterate while the queue is not empty
	while (!queue.empty()) {
// Dequeue a vertex from queue and print it
		int currVertex = queue.front();
		cout << currVertex << " ";
		queue.pop();
		/* Get all adjacent vertices of the dequeued vertex
		If an adjacent vertex has not been visited,
		mark it visited and enqueue it */
		for (int i = 0; i < graph.numVertices; i++) {
			if (graph.adjMatrix[currVertex][i] != 0 && !visited[i]) {
				visited[i] = true;
				queue.push(i);
			}
		}
	}
}

//(g) Đếm số cạnh đồ thị vô hướng
int countEdges(AdjMatrixGraph g) {
	int count = 0;
	for (int i = 0; i < g.numVertices; i++) {
		for (int j = i + 1; j < g.numVertices; j++) {
			if (g.adjMatrix[i][j] != 0)
				count++;
		}
	}
	return count;
}

//(h) Tính số cạnh vào đỉnh x (đồ thị có hướng)
int countIncomingEdges(AdjMatrixGraph g, int x) {
	int count = 0;
	for (int i = 0; i < g.numVertices; i++) {
		if (g.adjMatrix[i][x] != 0)
			count++;
	}
	return count;
}


//(i) Liệt kê các đỉnh không kề với đỉnh x
void notAdjacent(AdjMatrixGraph g, int x) {
	cout << "cac dinh khong ke voi dinh " << x << ": ";
	for (int i = 0; i < g.numVertices; i++) {
		if (i != x && g.adjMatrix[x][i] == 0)
			cout << i << " ";
	}
	cout << endl;
}

//(j) Liệt kê các đỉnh không thăm được từ đỉnh x
void notVisited(AdjMatrixGraph g, int x) {
	bool visited[MAX_VERTICES] = {false};

	DFS(g, x, visited);

	cout << "Cac dinh khong duoc tham tu dinh " << x << ": ";
	bool hasUnvisited = false;
	for (int i = 0; i < g.numVertices; ++i) {
		if (!visited[i]) {
			cout << i << " ";
			hasUnvisited = true;
		}
	}
	if (!hasUnvisited)
		cout << "khong co";
	cout << endl;
}

//k) Kiểm tra một dãy có phải đường đi không
bool isPath(AdjMatrixGraph g, int arr[], int k) {
	for (int i = 0; i < k - 1; i++) {
		if (g.adjMatrix[arr[i]][arr[i+1]] == 0)
			return false;
	}
	return true;
}

//(l) Liệt kê các đỉnh đi đến được đỉnh x (đồ thị có hướng)
void DFS2(const AdjMatrixGraph& graph, int vertex, bool visited[]) {
	visited[vertex] = true;
	for (int i = 0; i < graph.numVertices; i++) {
		if (graph.adjMatrix[vertex][i] != 0 && !visited[i]) {
			DFS2(graph, i, visited);
		}
	}
}
void pathToVertex(AdjMatrixGraph g, int x) {
	cout << "Cac dinh co the di den dinh " << x << ": ";
	for (int i = 0; i < g.numVertices; i++) {
		if (i == x) continue;
		bool visited[MAX_VERTICES];
		memset(visited, false, sizeof(visited));
		DFS2(g, i, visited);  // Dùng DFS không in
		if (visited[x])
			cout << i << " ";
	}
	cout << endl;
}




int main() {
	AdjMatrixGraph g;
	bool visited[MAX_VERTICES];
	memset(visited, false, sizeof(visited));
	readGraphFromFile("Graph1.txt", g);
	printGraph(g);
	DFS(g, 0, visited);



	AdjMatrixGraph g2;
//   bool visited[MAX_VERTICES];


	// Đọc đồ thị từ tệp
	readGraphFromFile("Graph2.txt", g2);
	// In ma trận kề
	cout << endl;
	printGraph(g2);
	cout << "duyet tu 1 dinh: ";
	memset(visited, false, sizeof(visited));
	DFS(g2, 1, visited); // duyệt từ đỉnh 1
	cout << endl;

	// Duyệt toàn bộ đồ thị (nếu không liên thông)
	cout << "Duyet het tat ca cac dinh voi do thi khong lien thong: ";
	traverseGraph(g);
	cout << endl;

	// Duyệt BFS từ đỉnh 0
	cout << "BFS tu dinh 0: ";
	BFS(g, 0);
	cout << endl;

	// Đếm số cạnh
	cout << "so canh la: " << countEdges(g) << endl;

	// Số cạnh vào đỉnh 2 (nếu đồ thị có hướng)
	cout << "So canh vao dinh 2: " << countIncomingEdges(g, 2) << endl;

	// Đỉnh không kề với đỉnh 1
	notAdjacent(g, 1);

	// Đỉnh không thăm được khi DFS từ đỉnh 0
	notVisited(g, 0);
	// Kiểm tra đường đi
	int path1[] = {0, 1, 2};
	cout << "Duong di 0 -> 1 -> 2 ";

	if (isPath(g, path1, 3)) {
		cout << "hop le" << endl;
	} else {
		cout << "khong hop le" << endl;
	}


	// Liệt kê các đỉnh đến được đỉnh 3
	pathToVertex(g, 3);

	return 0;


}