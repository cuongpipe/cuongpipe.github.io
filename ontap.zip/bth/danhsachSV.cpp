#include <iostream>
using namespace std;

struct SinhVien {
    string ten;
    double diem;
    SinhVien* next; // Con trỏ trỏ đến sinh viên tiếp theo
};

int main() {
    // Tạo sinh viên đầu tiên (node đầu)
    SinhVien* sv1 = new SinhVien{"An", 8.5, NULL};

    // Tạo sinh viên thứ hai
    SinhVien* sv2 = new SinhVien{"Bình", 7.0, NULL};
    sv1->next = sv2;  // Nối sv1 với sv2

    // Tạo sinh viên thứ ba
    SinhVien* sv3 = new SinhVien{"Chi", 9.2, NULL};
    sv2->next = sv3;  // Nối sv2 với sv3

    // Duyệt danh sách sinh viên
    SinhVien* hienTai = sv1;
    while (hienTai != NULL) {
        cout << "Ten: " << hienTai->ten << ", Diem: " << hienTai->diem << endl;
        hienTai = hienTai->next;
    }

    return 0;
}

