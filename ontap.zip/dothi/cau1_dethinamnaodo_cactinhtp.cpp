#include <iostream>
#include <string>
using namespace std;

struct DonViHanhChinh {
    string name;
    string type;
};

struct HCNode {
    DonViHanhChinh data;
    HCNode* child;
    HCNode* sibling;
};

HCNode* taoNut(const string& name, const string& type) {
    HCNode* p = new HCNode;
    p->data.name = name;
    p->data.type = type;
    p->child = nullptr;
    p->sibling = nullptr;
    return p;
}

void themCon(HCNode* cha, HCNode* con) {
    if (!cha->child) cha->child = con;
    else {
        HCNode* p = cha->child;
        while (p->sibling) p = p->sibling;
        p->sibling = con;
    }
}


HCNode* taoCay() {
    HCNode* goc = taoNut("Viet Nam", "Quoc Gia");

    HCNode* bd = taoNut("Binh Dinh", "Tinh");
    HCNode* dn = taoNut("Da Nang", "TP");
    HCNode* hn = taoNut("Ha Noi", "TP");
    HCNode* hcm = taoNut("HCM", "TP");

    themCon(goc, bd);
    themCon(goc, dn);
    themCon(goc, hn);
    themCon(goc, hcm);

    themCon(hcm, taoNut("Binh Thach", "Quan"));
    themCon(hcm, taoNut("Go Vap", "Quan"));
    themCon(hcm, taoNut("Thu Duc", "Quan"));

    return goc;
}
///c) Viết hàm in tên các TP/Tỉnh (1 điểm)
void printCities(HCNode* root) {
    if (root == nullptr) return;

    if (root->data.type == "TP" || root->data.type == "Tinh") {
        cout << root->data.name << endl;
    }

    HCNode* child = root->child;
    while (child) {
        printCities(child);
        child = child->sibling;
    }
}

//liet ke thanh pho thuoc trung uong (level 2)
void printCititructhuoctrunguong(HCNode* root, int level) {
    if (root == nullptr) return;

    //vì bắt đầu level = 0 nên khi nào level = 1 thì sẽ là level 2
	if (root->data.type == "TP" && level == 1) {
        cout << root->data.name << endl;
    }

    HCNode* child = root->child;
    while (child) {
        printCititructhuoctrunguong(child, level + 1);
        child = child->sibling;
    }
}


//Viết hàm xác định tỉnh/thành có nhiều đơn vị hành chính trực thuộc nhất
void findMaxSubdivisions(HCNode* root, string& maxName, int& maxCount) {
    if (root == nullptr) return;

    if (root->data.type == "TP" || root->data.type == "Tinh") {
        int count = 0;
        HCNode* p = root->child;
        while (p) {
            count++;
            p = p->sibling;
        }
        if (count > maxCount) {
            maxCount = count;
            maxName = root->data.name;
        }
    }

    HCNode* child = root->child;
    while (child) {
        findMaxSubdivisions(child, maxName, maxCount);
        child = child->sibling;
    }
}

//in cai cây
void inCay(HCNode* root, int space = 0) {
	if (root == nullptr) return;
	cout << string(space, ' ') << root->data.name << " (" << root->data.type << ")" << endl;
	HCNode* child = root->child;
	while (child != nullptr) {
		inCay(child, space + 4);
		child = child->sibling;
	}
}

HCNode* search(HCNode* root, string name) {
	HCNode *p, *result;
	if (!root) return nullptr;

	if (root->data.name == name)
		return root;
	else {
		p = root->child;
		while (p) {
			result = search(p, name);  // gọi đệ quy
			if (result) return result;
			else p = p->sibling;
		}
		return nullptr; // không tìm thấy trong tất cả nhánh con
	}
}


void printChildren(HCNode* root, string x) {
	HCNode* r = search(root, x);
	if (r != nullptr) {
		HCNode* p = r->child;
		while (p != nullptr) {
			cout << p->data.name << endl;
			p = p->sibling;
		}
	}
}

//int countPersons(HCNode* root) {
//	if(root == nullptr) return 0;
//	else {
//		int d = 1;
//		FT *p = root->child;
//		while (p != nullptr) {
//			d = d + countPersons(p);
//			p = p->sibling;
//		}
//		return d;
//	}
//}




int main() {
    HCNode* root = taoCay();
    // gọi các hàm xử lý ở đây: in tỉnh/thành, tìm nơi có nhiều đơn vị nhất, v.v.
    
    cout << endl;
    cout << "Tat ca thanh pho va tinh trong cay" << endl;
	printCities(root);
	cout << endl;
    
    cout << "Tat ca thanh pho truc thuoc trung uong(tuc la level 2)" << endl;
    //bat dau tu level = 0
	printCititructhuoctrunguong(root, 0);
    cout << endl;
    
    
    string maxName = "";
	int maxCount = -1;
    //Viết hàm xác định tỉnh/thành có nhiều đơn vị hành chính trực thuộc nhất    
    findMaxSubdivisions(root, maxName, maxCount); 
	cout << "Tinh/TP co nhieu don vi truc thuoc nhat: " << maxName << " (" << maxCount << " don vi)" << endl;
	inCay(root);	
	cout << endl;
	
	cout<<"Cac quan cua tp hcm" << endl;
	printChildren(root, "HCM");
}
