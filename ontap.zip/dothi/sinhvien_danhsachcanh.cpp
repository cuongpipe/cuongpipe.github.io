#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <cstring>
using namespace std;

#define MAX 100

struct Edge {
    int u, v;
};

struct Graph {
    int numVertices, numEdges;
    vector<Edge> edges;
    int adjMatrix[MAX][MAX]; // chuyển về ma trận kề
};


void readGraphFromFile(Graph &g, string fileName) {
    ifstream file(fileName);
    file >> g.numVertices >> g.numEdges;
    g.edges.resize(g.numEdges);
    memset(g.adjMatrix, 0, sizeof(g.adjMatrix));
    for (int i = 0; i < g.numEdges; i++) {
        file >> g.edges[i].u >> g.edges[i].v;
        g.adjMatrix[g.edges[i].u][g.edges[i].v] = 1;
        g.adjMatrix[g.edges[i].v][g.edges[i].u] = 1;
    }
    file.close();
}

void BFS(Graph g, int start) {
    bool visited[MAX] = {false};
    queue<int> q;
    visited[start] = true;
    q.push(start);
    cout << "Sinh vien cung tinh voi " << start << ": ";
    while (!q.empty()) {
        int u = q.front(); q.pop();
        cout << u << " ";
        for (int v = 0; v < g.numVertices; v++) {
            if (g.adjMatrix[u][v] && !visited[v]) {
                visited[v] = true;
                q.push(v);
            }
        }
    }
    cout << endl;
}

void DFS(Graph g, int u, bool visited[], vector<int> &comp) {
    visited[u] = true;
    comp.push_back(u);
    for (int v = 0; v < g.numVertices; v++) {
        if (g.adjMatrix[u][v] && !visited[v])
            DFS(g, v, visited, comp);
    }
}

void findConnectedComponents(Graph g) {
    bool visited[MAX] = {false};
    int count = 0;
    for (int i = 0; i < g.numVertices; i++) {
        if (!visited[i]) {
            count++;
            vector<int> comp;
            DFS(g, i, visited, comp);
            cout << "Tinh " << count << ": ";
            for (int x : comp) cout << x << " ";
            cout << endl;
        }
    }
    cout << "=> Co tat ca " << count << " tinh" << endl;
}

void shortestPath(Graph g, int s, int d) {
    bool visited[MAX] = {false};
    int parent[MAX];
    memset(parent, -1, sizeof(parent));
    queue<int> q;
    visited[s] = true;
    q.push(s);
    while (!q.empty()) {
        int u = q.front(); q.pop();
        for (int v = 0; v < g.numVertices; v++) {
            if (g.adjMatrix[u][v] && !visited[v]) {
                visited[v] = true;
                parent[v] = u;
                q.push(v);
            }
        }
    }
    if (!visited[d]) {
        cout << "Khong co duong di giua " << s << " va " << d << endl;
        return;
    }
    vector<int> path;
    for (int v = d; v != -1; v = parent[v]) path.push_back(v);
    cout << "Duong di ngan nhat tu " << s << " den " << d << ": ";
    for (int i = path.size() - 1; i >= 0; i--) cout << path[i] << " ";
    cout << endl;
}

int main() {
    Graph g;
    readGraphFromFile(g, "GraphQue_Edges.txt");

    int k; cout << "Nhap sinh vien can tim cung tinh: "; cin >> k;
    BFS(g, k);

    findConnectedComponents(g);

    int s, d;
    cout << "Nhap 2 sinh vien tim duong di ngan nhat: "; cin >> s >> d;
    shortestPath(g, s, d);

    return 0;
}
