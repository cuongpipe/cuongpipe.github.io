#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <stack>
#include <cstring>
using namespace std;

#define MAX 100

struct Graph {
    int numVertices, numEdges;
    vector<vector<int>> adjList; // Danh sách kề
};

// Đọc danh sách cạnh từ file và chuyển thành danh sách kề
void readGraphFromFile(Graph &g, const string &fileName) {
    ifstream file(fileName);
    if (!file) {
        cout << "Khong mo duoc file!" << endl;
        return;
    }

    file >> g.numVertices >> g.numEdges;
    g.adjList.resize(g.numVertices);

    for (int i = 0; i < g.numEdges; i++) {
        int u, v;
        file >> u >> v;
        g.adjList[u].push_back(v);
        g.adjList[v].push_back(u); // vì đồ thị vô hướng
    }

    file.close();
}

// Tìm các sinh viên cùng tỉnh (thành phần liên thông với k) dùng BFS
void BFS(Graph &g, int start) {
    bool visited[MAX] = {false};
    queue<int> q;
    visited[start] = true;
    q.push(start);
    cout << "Sinh vien cung tinh voi " << start << ": ";
    while (!q.empty()) {
        int u = q.front(); q.pop();
        cout << u << " ";
        for (int v : g.adjList[u]) {
            if (!visited[v]) {
                visited[v] = true;
                q.push(v);
            }
        }
    }
    cout << endl;
}

// DFS đệ quy để tìm thành phần liên thông
void DFS(Graph &g, int u, bool visited[], vector<int> &component) {
    visited[u] = true;
    component.push_back(u);
    for (int v : g.adjList[u]) {
        if (!visited[v])
            DFS(g, v, visited, component);
    }
}

// Tìm tất cả các thành phần liên thông (các tỉnh)
void findConnectedComponents(Graph &g) {
    bool visited[MAX] = {false};
    int count = 0;

    for (int i = 0; i < g.numVertices; i++) {
        if (!visited[i]) {
            count++;
            vector<int> comp;
            DFS(g, i, visited, comp);
            cout << "Tinh " << count << ": ";
            for (int x : comp)
                cout << x << " ";
            cout << endl;
        }
    }

    cout << "=> Co tat ca " << count << " tinh (thanh phan lien thong)." << endl;
}

// Tìm đường đi ngắn nhất giữa s và d bằng BFS
void shortestPath(Graph &g, int s, int d) {
    bool visited[MAX] = {false};
    int parent[MAX];
    memset(parent, -1, sizeof(parent));

    queue<int> q;
    visited[s] = true;
    q.push(s);

    while (!q.empty()) {
        int u = q.front(); q.pop();
        for (int v : g.adjList[u]) {
            if (!visited[v]) {
                visited[v] = true;
                parent[v] = u;
                q.push(v);
            }
        }
    }

    if (!visited[d]) {
        cout << "Khong co duong di giua " << s << " va " << d << endl;
        return;
    }

    vector<int> path;
    for (int v = d; v != -1; v = parent[v])
        path.push_back(v);

    cout << "Duong di ngan nhat tu " << s << " den " << d << ": ";
    for (int i = path.size() - 1; i >= 0; i--)
        cout << path[i] << " ";
    cout << endl;
}

// ======================= MAIN ========================
int main() {
    Graph g;
    readGraphFromFile(g, "GraphQue_Edges.txt");

    int k;
    cout << "Nhap sinh vien can tim cung tinh: ";
    cin >> k;
    BFS(g, k);

    findConnectedComponents(g);

    int s, d;
    cout << "Nhap 2 sinh vien tim duong di ngan nhat: ";
    cin >> s >> d;
    shortestPath(g, s, d);

    return 0;
}
