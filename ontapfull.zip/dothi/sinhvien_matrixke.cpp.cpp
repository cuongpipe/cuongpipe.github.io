#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
#include <cstring>
using namespace std;

#define MAX 100

struct Graph {
    int numVertices;
    int adjMatrix[MAX][MAX]; // Ma trận kề
};

// (1 điểm) Đọc ma trận kề từ file
void readGraphFromFile(Graph &g, string fileName) {
    ifstream file(fileName);
    if (!file) {
        cout << "Khong the mo file!" << endl;
        return;
    }
    file >> g.numVertices;
    for (int i = 0; i < g.numVertices; i++) {
        for (int j = 0; j < g.numVertices; j++) {
            file >> g.adjMatrix[i][j];
        }
    }
    file.close();
}

// (1 điểm) Duyệt BFS: tìm sinh viên cùng tỉnh với sinh viên k
void BFS(Graph g, int k) {
    bool visited[MAX] = {false};
    queue<int> q;
    visited[k] = true;
    q.push(k);
    cout << "Sinh vien cung tinh voi sinh vien " << k << ": ";
    while (!q.empty()) {
        int u = q.front(); q.pop();
        cout << u << " ";
        for (int v = 0; v < g.numVertices; v++) {
            if (g.adjMatrix[u][v] && !visited[v]) {
                visited[v] = true;
                q.push(v);
            }
        }
    }
    cout << endl;
}

// DFS hỗ trợ tìm thành phần liên thông
void DFS(Graph g, int u, bool visited[], vector<int>& component) {
    visited[u] = true;
    component.push_back(u);
    for (int v = 0; v < g.numVertices; v++) {
        if (g.adjMatrix[u][v] && !visited[v]) {
            DFS(g, v, visited, component);
        }
    }
}

// (1 điểm) Tìm các thành phần liên thông
void findConnectedComponents(Graph g) {
    bool visited[MAX] = {false};
    int count = 0;
    for (int i = 0; i < g.numVertices; i++) {
        if (!visited[i]) {
            count++;
            vector<int> component;
            DFS(g, i, visited, component);
            cout << "Tinh " << count << " gom cac sinh vien: ";
            for (int x : component) cout << x << " ";
            cout << endl;
        }
    }
    cout << "=> Co tat ca " << count << " tinh (thanh phan lien thong)" << endl;
}

// (1 điểm) Tìm đường đi ngắn nhất từ s đến d (BFS)
void shortestPath(Graph g, int s, int d) {
    bool visited[MAX] = {false};
    int parent[MAX];
    memset(parent, -1, sizeof(parent));
    queue<int> q;
    visited[s] = true;
    q.push(s);

    while (!q.empty()) {
        int u = q.front(); q.pop();
        for (int v = 0; v < g.numVertices; v++) {
            if (g.adjMatrix[u][v] && !visited[v]) {
                visited[v] = true;
                parent[v] = u;
                q.push(v);
            }
        }
    }

    if (!visited[d]) {
        cout << "Khong co duong di tu " << s << " den " << d << endl;
        return;
    }

    // In đường đi từ s -> d
    vector<int> path;
    for (int v = d; v != -1; v = parent[v]) {
        path.push_back(v);
    }
    cout << "Duong di ngan nhat tu " << s << " den " << d << ": ";
    for (int i = path.size() - 1; i >= 0; i--) cout << path[i] << " ";
    cout << endl;
}

// (1 điểm) Hàm main
int main() {
    Graph g;
    readGraphFromFile(g, "GraphQue.txt");

    cout << "\n== Thong tin sinh vien cung tinh ==" << endl;
    BFS(g, 0); // Cho biết sinh viên số 0 cùng tỉnh với ai

    cout << "\n== Danh sach cac tinh (thanh phan lien thong) ==" << endl;
    findConnectedComponents(g);

    cout << "\n== Tim duong di ngan nhat ==" << endl;
    int s, d;
    cout << "Nhap 2 sinh vien (s d): ";
    cin >> s >> d;
    shortestPath(g, s, d);

    return 0;
}
