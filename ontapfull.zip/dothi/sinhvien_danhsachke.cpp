#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <cstring>
using namespace std;

#define MAX 100

struct Node {
    int v;
    Node* next;
};

struct Graph {
    int numVertices;
    Node* adj[MAX];
};

void readGraphFromFile(Graph &g, string fileName) {
    ifstream file(fileName);
    file >> g.numVertices;
    for (int i = 0; i < g.numVertices; i++) {
        g.adj[i] = nullptr;
        int v;
        while (file >> v && v != -1) {
            Node* newNode = new Node{v, g.adj[i]};
            g.adj[i] = newNode;
        }
    }
    file.close();
}

void BFS(Graph g, int start) {
    bool visited[MAX] = {false};
    queue<int> q;
    visited[start] = true;
    q.push(start);
    cout << "Sinh vien cung tinh voi " << start << ": ";
    while (!q.empty()) {
        int u = q.front(); q.pop();
        cout << u << " ";
        for (Node* p = g.adj[u]; p; p = p->next) {
            if (!visited[p->v]) {
                visited[p->v] = true;
                q.push(p->v);
            }
        }
    }
    cout << endl;
}

void DFS(Graph g, int u, bool visited[], vector<int> &comp) {
    visited[u] = true;
    comp.push_back(u);
    for (Node* p = g.adj[u]; p; p = p->next) {
        if (!visited[p->v]) DFS(g, p->v, visited, comp);
    }
}

void findConnectedComponents(Graph g) {
    bool visited[MAX] = {false};
    int count = 0;
    for (int i = 0; i < g.numVertices; i++) {
        if (!visited[i]) {
            vector<int> comp;
            count++;
            DFS(g, i, visited, comp);
            cout << "Tinh " << count << ": ";
            for (int v : comp) cout << v << " ";
            cout << endl;
        }
    }
    cout << "=> Co tat ca " << count << " tinh." << endl;
}

void shortestPath(Graph g, int s, int d) {
    bool visited[MAX] = {false};
    int parent[MAX];
    memset(parent, -1, sizeof(parent));
    queue<int> q;
    visited[s] = true;
    q.push(s);
    while (!q.empty()) {
        int u = q.front(); q.pop();
        for (Node* p = g.adj[u]; p; p = p->next) {
            if (!visited[p->v]) {
                visited[p->v] = true;
                parent[p->v] = u;
                q.push(p->v);
            }
        }
    }
    if (!visited[d]) {
        cout << "Khong co duong di giua " << s << " va " << d << endl;
        return;
    }
    vector<int> path;
    for (int v = d; v != -1; v = parent[v]) path.push_back(v);
    cout << "Duong di ngan nhat tu " << s << " den " << d << ": ";
    for (int i = path.size() - 1; i >= 0; i--) cout << path[i] << " ";
    cout << endl;
}

int main() {
    Graph g;
    readGraphFromFile(g, "GraphQue_List.txt");

    int k; cout << "Nhap sinh vien can tim cung tinh: "; cin >> k;
    BFS(g, k);

    findConnectedComponents(g);

    int s, d;
    cout << "Nhap 2 sinh vien tim duong di ngan nhat: "; cin >> s >> d;
    shortestPath(g, s, d);

    return 0;
}
