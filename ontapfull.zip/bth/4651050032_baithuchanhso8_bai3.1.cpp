#include <iostream>
#include <queue>
#include <vector>
using namespace std;

struct Student {
    string name;
    int age;
    float gpa;
};

struct CompareGPA {
    bool operator()(const Student& a, const Student& b) {
        return a.gpa > b.gpa; // Điểm trung bình tăng dần
    }
};

struct CompareAgeDecrease {
    bool operator()(const Student& a, const Student& b) {
        return a.age < b.age; // Tuổi giảm dần
    }
};

struct CompareNameIncrease {
    bool operator()(const Student& a, const Student& b) {
        return a.name > b.name; // Tên tăng dần
    }
};

void printQueue(priority_queue<Student, vector<Student>, auto> pq) {
    while (!pq.empty()) {
        Student top = pq.top();
        cout << top.name << " " << top.age << " " << top.gpa << endl;
        pq.pop();
    }
}

int main() {
    Student s1 = {"A Lit", 20, 3.8};
    Student s2 = {"Bop", 22, 3.5};
    Student s3 = {"Chac le", 21, 4.0};

    cout << "Diem trung binh tang" << endl;
    priority_queue<Student, vector<Student>, CompareGPA> pq_gpa;
    pq_gpa.push(s1);
    pq_gpa.push(s2);
    pq_gpa.push(s3);
    printQueue(pq_gpa);

    cout << "Tuoi giam dan" << endl;
    priority_queue<Student, vector<Student>, CompareAgeDecrease> pq_age;
    pq_age.push(s1);
    pq_age.push(s2);
    pq_age.push(s3);
    printQueue(pq_age);

    cout << "Ten tang" << endl;
    priority_queue<Student, vector<Student>, CompareNameIncrease> pq_name;
    pq_name.push(s1);
    pq_name.push(s2);
    pq_name.push(s3);
    printQueue(pq_name);

    return 0;
}
