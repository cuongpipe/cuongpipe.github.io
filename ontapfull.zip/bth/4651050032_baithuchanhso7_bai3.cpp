#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Node {
	string name;
	bool isFile;
	int size; // Chỉ áp dụng cho file
	vector<Node*> children; // Dành cho thư mục

	Node(string n, bool file = false, int s = 0) {
		name = n;
		isFile = file;
		if (file) {
			size = s;
		} else {
			size = 0;
		}
	}

};

//a) Tạo một cây thư mục cụ thể
Node* createTree() {
	Node* root = new Node("Root", false);

	Node* folderA = new Node("FolderA", false);
	Node* file1 = new Node("file1.txt", true, 100);
	Node* file2 = new Node("file2.txt", true, 200);
	folderA->children.push_back(file1);
	folderA->children.push_back(file2);

	Node* folderB = new Node("FolderB", false);
	Node* folderC = new Node("FolderC", false);
	Node* file3 = new Node("file3.txt", true, 300);
	folderC->children.push_back(file3);
	folderB->children.push_back(folderC);

	root->children.push_back(folderA);
	root->children.push_back(folderB);
	root->children.push_back(new Node("readme.md", true, 50));

	return root;
}


//b) In cây thư mục (dạng cây)
void printTree(Node* root, string indent = "") {
	cout << indent;
	if (root->isFile) {
		cout << "[FILE] ";
	} else {
		cout << "[DIR]  ";
	}
	cout << root->name;

	if (root->isFile) {
		cout << " (" << root->size << "KB)";
	}
	cout << endl;



	for (Node* child : root->children) {
		printTree(child, indent + "  ");
	}
}

//Hàm c) Tìm một tập tin hay thư mục
bool findNode(Node* root, const string& name) {
	if (root->name == name) return true;

	for (Node* child : root->children) {
		if (findNode(child, name)) return true;
	}
	return false;
}

//d) Tính tổng kích thước các tập tin
int totalSize(Node* root) {
	int total = 0;
	if (root->isFile) return root->size;

	for (Node* child : root->children) {
		total += totalSize(child);
	}
	return total;
}

//e) Liệt kê đường dẫn đến file theo tên
void findPaths(Node* root, const string& fileName, string currentPath, vector<string>& results) {
	string path = currentPath + "/" + root->name;
	if (root->isFile && root->name == fileName) {
		results.push_back(path);
	}
	for (Node* child : root->children) {
		findPaths(child, fileName, path, results);
	}
}


//f) Xóa một tập tin
bool deleteFile(Node* root, const string& fileName) {
	for (auto it = root->children.begin(); it != root->children.end(); ++it) {
		Node* child = *it;
		if (child->isFile && child->name == fileName) {
			delete child;
			root->children.erase(it);
			return true;
		} else if (!child->isFile) {
			if (deleteFile(child, fileName)) return true;
		}
	}
	return false;
}
// g) Xóa một thư mục (đệ quy)
bool deleteDirectory(Node* root, const string& dirName) {
	for (auto it = root->children.begin(); it != root->children.end(); ++it) {
		Node* child = *it;
		if (!child->isFile && child->name == dirName) {
			// Gọi đệ quy để xóa tất cả con
			for (Node* sub : child->children)
				deleteDirectory(sub, sub->name);
			delete child;
			root->children.erase(it);
			return true;
		} else if (!child->isFile) {
			if (deleteDirectory(child, dirName)) return true;
		}
	}
	return false;
}

int main() {
	Node* root = createTree();

	cout << "Cay thu muc:"<<endl;
	printTree(root);

	string findName = "file2.txt";
	cout << endl << "Tim " << findName << ": ";
	if (findNode(root, findName)) {
		cout << "Tim thay!" << endl;
	} else {
		cout << "Khong thay!" << endl;
	}


	cout << endl << "Tong kich thuoc tap tin: " << totalSize(root) << "KB"<<endl;

	vector<string> paths;
	findPaths(root, "file3.txt", "", paths);
	cout << endl <<"Duong dan den file3.txt:"<<endl;
	for (string p : paths) cout << p << endl;

	cout << endl << "Xoa file file2.txt..."<<endl;
	deleteFile(root, "file2.txt");
	printTree(root);

	cout << endl <<"Xoa thu muc FolderC..."<<endl;
	deleteDirectory(root, "FolderC");
	printTree(root);

	return 0;
}

