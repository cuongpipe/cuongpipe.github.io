#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
#include <stack>
using namespace std;

#define MAX_VERTICES 100
#define INF 1000

struct AdjList {
	int adjVertex;
	float weight;
	AdjList* next;
};

struct AdjListGraph {
	int numVertices;
	AdjList* adjList[MAX_VERTICES];
};

// a) Đọc đồ thị từ tệp
void readGraphFromFile(AdjListGraph& graph, string fileName) {
	ifstream file(fileName);
	file >> graph.numVertices;
	for (int i = 0; i < graph.numVertices; i++) {
		graph.adjList[i] = nullptr;
		for (int j = 0; j < graph.numVertices; j++) {
			float weight;
			file >> weight;
			if (weight != INF) {
				AdjList* newNode = new AdjList{ j, weight, graph.adjList[i] };
				graph.adjList[i] = newNode;
			}
		}
	}
	file.close();
}

// b) In đồ thị
void printGraph(AdjListGraph graph) {
	cout << "Num of vertices: " << graph.numVertices << endl;
	for (int i = 0; i < graph.numVertices; i++) {
		cout << "adjList[" << i << "]: ";
		for (AdjList* p = graph.adjList[i]; p != nullptr; p = p->next) {
			cout << p->adjVertex << "(" << p->weight << ") ";
		}
		cout << endl;
	}
}

// c) BFS
void PathBFS(AdjListGraph graph, int s, int parent[]) {
	bool visited[MAX_VERTICES] = { false };
	for (int i = 0; i < graph.numVertices; i++) parent[i] = -1;
	queue<int> q;
	visited[s] = true;
	parent[s] = s;
	q.push(s);
	while (!q.empty()) {
		int curr = q.front();
		q.pop();
		for (AdjList* p = graph.adjList[curr]; p != nullptr; p = p->next) {
			if (!visited[p->adjVertex]) {
				visited[p->adjVertex] = true;
				parent[p->adjVertex] = curr;
				q.push(p->adjVertex);
			}
		}
	}
}

// d) In đường đi
void printPath(int parent[], int s, int v) {
	if (parent[v] == -1) {
		cout << "Khong co duong di tu " << s << " den " << v << endl;
		return;
	}
	if (v == s) {
		cout << s << " ";
		return;
	}
	printPath(parent, s, parent[v]);
	cout << v << " ";
}

// e) DFS & kiểm tra liên thông
void DFS(AdjListGraph graph, int v, bool visited[]) {
	visited[v] = true;
	for (AdjList* p = graph.adjList[v]; p != NULL; p = p->next) {
		if (!visited[p->adjVertex])
			DFS(graph, p->adjVertex, visited);
	}
}

bool isConnected(AdjListGraph graph) {
	bool visited[MAX_VERTICES] = { false };
	DFS(graph, 0, visited);
	for (int i = 0; i < graph.numVertices; i++)
		if (!visited[i])
			return false;
	return true;
}

// f, g) Thành phần liên thông
void DFSConnectedComponents(AdjListGraph graph, int v, bool visited[], int component[], int k) {
	visited[v] = true;
	component[v] = k;
	for (AdjList* p = graph.adjList[v]; p != NULL; p = p->next) {
		if (!visited[p->adjVertex])
			DFSConnectedComponents(graph, p->adjVertex, visited, component, k);
	}
}

int connectedComponents(AdjListGraph graph, int component[]) {
	bool visited[MAX_VERTICES] = { false };
	int k = 0;
	for (int i = 0; i < graph.numVertices; i++) {
		if (!visited[i]) {
			k++;
			DFSConnectedComponents(graph, i, visited, component, k);
		}
	}
	return k;
}

void printConnectedComponents(int component[], int n, int k) {
	cout << "So luong thanh phan lien thong: " << k << endl;
	for (int i = 1; i <= k; i++) {
		cout << "Thanh phan[" << i << "]: ";
		for (int j = 0; j < n; j++)
			if (component[j] == i)
				cout << j << " ";
		cout << endl;
	}
}

// h) Kiểm tra có đường đi giữa 2 đỉnh
bool hasPath(int parent[], int s, int d) {
	return parent[d] != -1;
}

// i) Tìm đường đi bằng DFS
bool pathDFSUtil(AdjListGraph graph, int u, int d, bool visited[], int parent[]) {
	visited[u] = true;
	if (u == d) return true;
	for (AdjList* p = graph.adjList[u]; p != nullptr; p = p->next) {
		if (!visited[p->adjVertex]) {
			parent[p->adjVertex] = u;
			if (pathDFSUtil(graph, p->adjVertex, d, visited, parent))
				return true;
		}
	}
	return false;
}

void pathDFS(AdjListGraph graph, int s, int d, int parent[]) {
	bool visited[MAX_VERTICES] = { false };
	for (int i = 0; i < graph.numVertices; i++) parent[i] = -1;
	parent[s] = s;
	if (!pathDFSUtil(graph, s, d, visited, parent))
		cout << "Khong co duong di DFS tu " << s << " den " << d << endl;
}

// j) Đường đi không qua đỉnh v
bool dfsAvoidVertex(AdjListGraph graph, int u, int d, int avoid, bool visited[], vector<int>& path) {
	if (u == avoid) return false;
	visited[u] = true;
	path.push_back(u);
	if (u == d) return true;
	for (AdjList* p = graph.adjList[u]; p != nullptr; p = p->next) {
		if (!visited[p->adjVertex]) {
			if (dfsAvoidVertex(graph, p->adjVertex, d, avoid, visited, path))
				return true;
		}
	}
	path.pop_back();
	return false;
}

vector<int> pathNoVertex(AdjListGraph graph, int s, int d, int v) {
	bool visited[MAX_VERTICES] = { false };
	vector<int> path;
	if (dfsAvoidVertex(graph, s, d, v, visited, path))
		return path;
	return {};
}

// k) Đường đi chỉ qua cạnh ≥ M
bool dfsWeightLimit(AdjListGraph graph, int u, int d, int M, bool visited[], vector<int>& path) {
	visited[u] = true;
	path.push_back(u);
	if (u == d) return true;
	for (AdjList* p = graph.adjList[u]; p != nullptr; p = p->next) {
		if (!visited[p->adjVertex] && p->weight >= M) {
			if (dfsWeightLimit(graph, p->adjVertex, d, M, visited, path))
				return true;
		}
	}
	path.pop_back();
	return false;
}

vector<int> pathGreatThan(AdjListGraph graph, int s, int d, int M) {
	bool visited[MAX_VERTICES] = { false };
	vector<int> path;
	if (dfsWeightLimit(graph, s, d, M, visited, path))
		return path;
	return {};
}

// l) Kiểm tra liên thông mạnh
void transposeGraph(AdjListGraph graph, AdjListGraph& transposed) {
	transposed.numVertices = graph.numVertices;
	for (int i = 0; i < graph.numVertices; i++) transposed.adjList[i] = nullptr;

	for (int i = 0; i < graph.numVertices; i++) {
		for (AdjList* p = graph.adjList[i]; p != nullptr; p = p->next) {
			AdjList* newNode = new AdjList{ i, p->weight, transposed.adjList[p->adjVertex] };
			transposed.adjList[p->adjVertex] = newNode;
		}
	}
}

bool strongConnected(AdjListGraph graph) {
	bool visited[MAX_VERTICES] = { false };
	DFS(graph, 0, visited);
	for (int i = 0; i < graph.numVertices; i++)
		if (!visited[i])
			return false;

	AdjListGraph transposed;
	transposeGraph(graph, transposed);
	fill(begin(visited), end(visited), false);
	DFS(transposed, 0, visited);
	for (int i = 0; i < transposed.numVertices; i++)
		if (!visited[i])
			return false;
	return true;
}

// m) In tất cả các đường đi đơn
void allPathsUtil(AdjListGraph graph, int u, int d, bool visited[], vector<int>& path, vector<vector<int>>& paths) {
	visited[u] = true;
	path.push_back(u);
	if (u == d) {
		paths.push_back(path);
	} else {
		for (AdjList* p = graph.adjList[u]; p != nullptr; p = p->next) {
			if (!visited[p->adjVertex])
				allPathsUtil(graph, p->adjVertex, d, visited, path, paths);
		}
	}
	path.pop_back();
	visited[u] = false;
}

void allPaths(AdjListGraph graph, int s, int d, vector<vector<int>>& paths) {
	bool visited[MAX_VERTICES] = { false };
	vector<int> path;
	allPathsUtil(graph, s, d, visited, path, paths);
}


void readGraphFromMatrixFile(AdjListGraph& graph, string fileName) {
    ifstream file(fileName);
    if (!file) {
        cerr << "Khong the mo file " << fileName << endl;
        return;
    }
    file >> graph.numVertices;
    for (int i = 0; i < graph.numVertices; i++) {
        graph.adjList[i] = nullptr;
    }

    int val;
    for (int i = 0; i < graph.numVertices; i++) {
        for (int j = 0; j < graph.numVertices; j++) {
            file >> val;
            if (val != 0) { // chỉ thêm cạnh nếu có kết nối
                AdjList* newNode = new AdjList{ j, 1.0, graph.adjList[i] }; // trọng số có thể bỏ qua hoặc set = 1
                graph.adjList[i] = newNode;
            }
        }
    }

    file.close();
}








// Hàm main
int main() {
	AdjListGraph g;
	readGraphFromFile(g, "Graph4.txt"); // đổi thành Graph5.txt nếu cần
	printGraph(g);

	int s, d;
	cout << "Nhap dinh bat dau: ";
	cin >> s;
	cout << "Nhap dinh dich: ";
	cin >> d;

	int parent[MAX_VERTICES];
	PathBFS(g, s, parent);
	cout << "Duong di BFS tu " << s << " den " << d << ": ";
	printPath(parent, s, d);
	cout << endl;

	pathDFS(g, s, d, parent);
	cout << "Duong di DFS tu " << s << " den " << d << ": ";
	printPath(parent, s, d);
	cout << endl;

	int avoid;
	cout << "Nhap dinh can tranh: ";
	cin >> avoid;
	vector<int> path1 = pathNoVertex(g, s, d, avoid);
	cout << "Duong di tranh dinh " << avoid << ": ";
	for (int v : path1) cout << v << " ";
	if (path1.empty()) cout << "Khong co duong di";
	cout << endl;

	int M;
	cout << "Nhap canh toi thi con: ";
	cin >> M;
	vector<int> path2 = pathGreatThan(g, s, d, M);
	cout << "Duong di voi canh >= " << M << ": ";
	for (int v : path2) cout << v << " ";
	if (path2.empty()) cout << "Khong co duong di";
	cout << endl;

	bool connected = isConnected(g);
	if (connected) {
		cout << "Do thi lien thong" << endl;
	} else {
		cout << "Do thi khong lien thong" << endl;
	}


	int comp[MAX_VERTICES] = { -1 };
	int k = connectedComponents(g, comp);
	printConnectedComponents(comp, g.numVertices, k);

	cout << "Do thi co lien thong manh? ";
	if (strongConnected(g)) {
		cout << "Co" << endl;
	} else {
		cout << "Khong" << endl;
	}

	vector<vector<int>> paths;
	allPaths(g, s, d, paths);
	cout << "Tat ca cac duong di don tu " << s << " den " << d << ":" << endl;
	for (auto p : paths) {
		for (int v : p) cout << v << " ";
		cout << endl;
	}
	
	
	
	
	 // Xử lý file graph5.txt
    AdjListGraph g5;
    readGraphFromMatrixFile(g5, "Graph5.txt"); // Đọc từ ma trận kề
    printGraph(g5); // In ra để kiểm tra

    // Kiểm tra liên thông
    if (isConnected(g5)) {
        cout << "Do thi (Graph5.txt) lien thong." << endl;
    } else {
        cout << "Do thi (Graph5.txt) KHONG lien thong." << endl;
    }

    // Thành phần liên thông
    int comp2[MAX_VERTICES] = { -1 };
    int k2 = connectedComponents(g5, comp2);
    printConnectedComponents(comp2, g5.numVertices, k);

	return 0;
}
