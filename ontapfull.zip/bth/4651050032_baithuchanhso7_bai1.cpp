#include<iostream>
#include<queue>
using namespace std;

struct Person {
	string name;
	int yearOfBirth;
};

struct FT {
	Person data;
	FT *child, *sibling;
	// child: luu dia chi nut con dau tien (neu co)
	// sibling: luu dia chi nut em lien ke (neu co)
};

//FT *taoCay() {
//	// Tao nut goc
//	FT *root = new FT{{"Nguyen A", 1900}, nullptr, nullptr};
//
//	FT *B = new FT{{"Nguyen B", 1930}, nullptr, nullptr};
//	root->child = B; //
//
//	FT *C = new FT{{"Nguyen C", 1935}, nullptr, nullptr};
//	B->sibling = C; // B co em la C
//
//	FT *D = new FT{{"Nguyen D", 1995}, nullptr, nullptr};
//	B->child = D; // B co con la D
//
//	FT *E = new FT{{"Nguyen E", 1960}, nullptr, nullptr};
//	D->sibling = E; // C co em la D
//
//	FT *F = new FT{{"Nguyen F", 1965}, nullptr, nullptr};
//	E->sibling = F; // C co em la D
//
//	FT *G = new FT{{"Nguyen G", 1965}, nullptr, nullptr};
//	C->child = G; // C co em la D
//
//	FT *H = new FT{{"Nguyen H", 1970}, nullptr, nullptr};
//	G->sibling = H; // C co em la D
//
//	return root;
//}


// Hàm thêm 1 người con vào node có tên là 'parentName' (thêm vào cuối danh sách con)
void addChild(FT* root, string parentName, Person childPerson) {
	if (!root) return;

	if (root->data.name == parentName) {
		FT* newNode = new FT{childPerson, nullptr, nullptr};
		if (!root->child) {
			root->child = newNode;
		} else {
			FT* p = root->child;
			while (p->sibling)
				p = p->sibling;
			p->sibling = newNode;
		}
		return;
	}

	FT* child = root->child;
	while (child) {
		addChild(child, parentName, childPerson);
		child = child->sibling;
	}
}


FT* taoCay() {
	FT* root = new FT{{"Nguyen A", 1900}, nullptr, nullptr};

	addChild(root, "Nguyen A", {"Nguyen B", 1930});
	addChild(root, "Nguyen A", {"Nguyen C", 1935});

	addChild(root, "Nguyen B", {"Nguyen D", 1995});
	addChild(root, "Nguyen B", {"Nguyen E", 1960});
	addChild(root, "Nguyen B", {"Nguyen F", 1965});

	addChild(root, "Nguyen C", {"Nguyen G", 1965});
	addChild(root, "Nguyen C", {"Nguyen H", 1970});

	return root;
}




// duyet theo chieu sau
void DFS(FT *root) {
	if(root != nullptr) {
		cout << root->data.name <<" "<< root->data.yearOfBirth << " ";
		FT *r = root->child;  // Gán đúng giá trị ban đầu

		while(r != nullptr) {
			DFS(r);
			r = r->sibling;
		}
	}
}


void BFS(FT *root) {
	queue<FT*> q;
	FT *r;
	if (root != nullptr) {
		q.push(root);
		while (!q.empty()) {
			r = q.front();
			q.pop();
			cout << r->data.name <<" "<< r->data.yearOfBirth << " ";
			r = r->child;
			while (r != nullptr) {
				q.push(r);
				r = r->sibling;
			}
		}
	}
}

void inCay(FT* root, int space = 0) {
	if (root == nullptr) return;
	cout << string(space, ' ') << root->data.name << " (" << root->data.yearOfBirth << ")" << endl;
	FT* child = root->child;
	while (child != nullptr) {
		inCay(child, space + 4);
		child = child->sibling;
	}
}


//tim nguoi ten x trong cay tai p.
//Sau do tim nguoi ten y trong cay nut goc la p.
bool isChild(FT* root, string x, string y) {
	if (!root) return false;
	if (root->data.name == x) {
		FT* child = root->child;
		while (child != nullptr) {
			if (child->data.name == y)
				return true;
			child = child->sibling;
		}
		return false;
	}
	FT* child = root->child;
	while (child != nullptr) {
		if (isChild(child, x, y))
			return true;
		child = child->sibling;
	}
	return false;
}


//g) Them nguoi q vao con cua nguoi ten x trong cay. Biet rang cac nut con cua mot nguoi
//duoc sap theo thu tu tang cua nam sinh.
//Goi y: tim nguoi ten x trong cay tai nut p. Duyet cac nut con cua nut p de tim vi tri phu
//hop them nguoi q vao.
void insertChild(FT* root, string x, Person q) {
	if (!root) return;

	if (root->data.name == x) {
		FT* newNode = new FT{q, nullptr, nullptr};

		FT* &firstChild = root->child;
		if (!firstChild || q.yearOfBirth < firstChild->data.yearOfBirth) {
			newNode->sibling = firstChild;
			firstChild = newNode;
			return;
		}

		FT* prev = firstChild;
		FT* curr = firstChild->sibling;
		while (curr && curr->data.yearOfBirth < q.yearOfBirth) {
			prev = curr;
			curr = curr->sibling;
		}
		newNode->sibling = curr;
		prev->sibling = newNode;
		return;
	}

	FT* child = root->child;
	while (child) {
		insertChild(child, x, q);
		child = child->sibling;
	}
}


//h) Liet ke con, chau cua mot nguoi co ho ten x.
//Goiy: tim nguoi ten x trong cay tai nut p. Sau do in tat ca nhung cay co goc la con cua
//p.
void printDescendants(FT* root, string x) {
	if (!root) return;
	if (root->data.name == x) {
		FT* child = root->child;
		while (child) {
			cout << "Con: " << child->data.name << " (" << child->data.yearOfBirth << ")" << endl;
			FT* grandchild = child->child;
			while (grandchild) {
				cout << "  Chau: " << grandchild->data.name << " (" << grandchild->data.yearOfBirth << ")" << endl;
				grandchild = grandchild->sibling;
			}
			child = child->sibling;
		}
		return;
	}

	FT* child = root->child;
	while (child) {
		printDescendants(child, x);
		child = child->sibling;
	}
}


//i) In nhung nguoi thuoc the he thu k.
void printByLevel(FT* root, int k, int level = 1) {


	if (!root) return;

	if (level == k) {
		cout << root->data.name << " (" << root->data.yearOfBirth << ")" << endl;
	}

	FT* child = root->child;
	while (child) {
		printByLevel(child, k, level + 1);// đệ quy

		child = child->sibling;
	}
}


//j) Tinh bac cua cay.
//Goiy: duyet tung nut, moi nut dem so nut con sau do chon so nut con lon nhat.
int degree(FT* root) {
	if (!root) return 0;

	int count = 0;
	FT* child = root->child;
	while (child) {
		count++;
		child = child->sibling;
	}

	int maxChild = count;
	child = root->child;
	while (child) {
		int deg = degree(child);
		if (deg > maxChild)
			maxChild = deg;
		child = child->sibling;
	}

	return maxChild;
}


// k) Xoa nguoi tren cay co ten x (x khong phai ong to cua dong ho).
// Goiy: Tim nguoi ten x tai nut p va p1 la nut cha cua p va p2 la nut anh lien ke cua p. Neu
// p la nut con truong thi chuyen nut con cua p1 la em lien ke cua p. Nguoc lai chuyen em
// lien ke cua p2 la em lien ke cua p. Sau do xoa toan bo cay nut goc la p.
// Xóa cây con của một nút
FT* findByName(FT* root, const string& name) {
    if (!root) return nullptr;
    if (root->data.name == name) return root;
    for (FT* child = root->child; child; child = child->sibling) {
        FT* found = findByName(child, name);
        if (found) return found;
    }
    return nullptr;
}

void deleteByName(FT* root, const string& x) {
	if (!root || root->child == nullptr) return;

	FT* curr = root->child;
	FT* prev = nullptr;

	while (curr != nullptr) {
		FT* next = curr->sibling; // lưu lại trước để an toàn

		if (curr->data.name == x) {
			if (prev == nullptr) {
				root->child = curr->sibling;
			} else {
				prev->sibling = curr->sibling;
			}
			return; // THOÁT NGAY khi đã xóa
		} else {
			// Gọi đệ quy trước khi gán prev/curr
			deleteByName(curr, x);
		}

		prev = curr;
		curr = next;
	}
}






int main() {
	FT* root = taoCay();

	cout <<"Duyet theo chieu sau" << endl;
	DFS(root);

	cout << endl << "Duyet theo chieu rong" << endl;
	BFS(root);

	cout << endl;

	cout << "In cay pha he (in ra dang cay):" << endl;
	inCay(root);
	cout << endl;

	// Kiem tra la con hay khong
	cout << "Kiem tra la con: " << endl;
	if (isChild(root, "Nguyen A", "Nguyen B")) {
		cout << "Nguyen B la con cua Nguyen A: Yes" << endl;
	} else {
		cout << "Nguyen B la con cua Nguyen A: No" << endl;
	}

	if (isChild(root, "Nguyen B", "Nguyen C")) {
		cout << "Nguyen C la con cua Nguyen B: Yes" << endl;
	} else {
		cout << "Nguyen C la con cua Nguyen B: No" << endl;
	}


	// Them nguoi vao cay
	Person newPerson = {"Nguyen J", 1967};
	
	insertChild(root, "Nguyen C", newPerson);
	
	cout << "In cay sau khi them nguoi Nguyen J vao con cua Nguyen C:" << endl;
	inCay(root);
	cout << endl;

	// In con va chau cua nguoi co ten Nguyen C
	cout << "Con va chau cua Nguyen C: " << endl;
	printDescendants(root, "Nguyen C");

	// In nhung nguoi thuoc the he thu 2
	int k2 = 1;
	cout << "Nhung nguoi thuoc the he thu" << k2 << ": " << endl;
	printByLevel(root, k2);

	// Tinh bac cua cay
	cout << "Bac cua cay: " << degree(root) << endl;

	// Xoa nguoi co ten Nguyen D
	if (root->data.name == "Nguyen D") {
	    cout << "Khong the xoa ong to dong ho!" << endl;
	} 
	else {
	    deleteByName(root, "Nguyen D");
	}

	if (root) {
		cout << "In cay sau khi xoa Nguyen D: " << endl;
		inCay(root);
	}


	return 0;
}