#include <iostream>
#include <stack>

using namespace std;

// Hàm xác định mức ưu tiên của toán tử
int mucUuTien(char c) {
    if (c == '+' || c == '-') return 1; // Cộng và trừ có mức ưu tiên 1
    else if (c == '*' || c == '/') return 2; // Nhân và chia có mức ưu tiên 2
    else return -1; // Các ký tự khác không có mức ưu tiên
}

// Hàm chuyển đổi biểu thức trung tố sang hậu tố
string chuyenDoi(string s) {
    string ketQua; // Chuỗi kết quả lưu biểu thức hậu tố
    stack<char> st; // Ngăn xếp dùng để lưu toán tử
    
    for (char c : s) {
        if (isalnum(c)) {  // Nếu là toán hạng (số hoặc chữ cái)
            ketQua += c; // Thêm vào chuỗi kết quả
        } 
        else if (c == '(') { // Nếu là dấu mở ngoặc
            st.push(c); // Đưa vào ngăn xếp
        } 
        else if (c == ')') { // Nếu là dấu đóng ngoặc
            while (!st.empty() && st.top() != '(') { // Lấy toán tử ra khỏi ngăn xếp cho đến khi gặp '('
                ketQua += st.top();
                st.pop();
            }
            if (!st.empty()) st.pop();  // Loại bỏ dấu '(' khỏi stack
        } 
        else {  // Nếu là toán tử
            while (!st.empty() && mucUuTien(st.top()) >= mucUuTien(c) && st.top() != '(') { // Kiểm tra mức ưu tiên
                ketQua += st.top();
                st.pop();
            }
            st.push(c); // Đưa toán tử vào ngăn xếp
        }
    }

    // Pop các phần tử còn lại trong stack
    while (!st.empty()) {
        ketQua += st.top(); // Lấy toán tử ra khỏi stack
        st.pop();
    }

    return ketQua; // Trả về biểu thức hậu tố
}

int main() {
    int n; // Số lượng biểu thức cần chuyển đổi
    cin >> n; // Nhập số lượng biểu thức
    cin.ignore();  // Loại bỏ ký tự xuống dòng sau khi nhập n

    while (n--) { // Lặp qua từng biểu thức
        string s; // Chuỗi chứa biểu thức trung tố
        getline(cin, s);  // Nhập cả dòng để tránh lỗi nhập thiếu
        cout <<"ket-qua: "<< chuyenDoi(s) << endl; // In ra biểu thức hậu tố
    }

    return 0; // Kết thúc chương trình
}

///vd 
//3
//A+B
//(A+B)*C
//A+B*C-(D/E)

//kq: 
//3
//A+B
//ket-qua: AB+
//(A+B)*C
//ket-qua: AB+C*
//A+B*C-(D/E)
//ket-qua: ABC*+DE/-

