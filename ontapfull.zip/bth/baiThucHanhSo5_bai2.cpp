#include <bits/stdc++.h>
using namespace std;

struct Node {
	char data;
	Node* left;
	Node* right;
};

// tao node
Node* taoNode(char data, Node* left, Node* right) {
	return new Node{data, left, right};
}

Node* taoCay() {
	Node* n1 = taoNode('D', nullptr, nullptr);
	Node* n2 = taoNode('E', nullptr, nullptr);
	Node* n3 = taoNode('F', nullptr, nullptr);
	Node* n4 = taoNode('G', nullptr, nullptr);
	Node* n5 = taoNode('B', n1, n2);
	Node* n6 = taoNode('C', n3, n4);
	Node* root = taoNode('A', n5, n6);

	return root;
}

// duyet theo thu tu truoc
void duyetTruoc(Node* root) {
	if (root) {
		cout << root->data << " ";
		duyetTruoc(root->left);
		duyetTruoc(root->right);
	}
}

// duyet theo thu tu giua
void duyetGiua(Node* root) {
	if (root) {
		duyetGiua(root->left);
		cout << root->data << " ";
		duyetGiua(root->right);
	}
}

int main() {
	Node* root = taoCay();

	cout << "Duyet theo thu tu truoc: ";
	duyetTruoc(root);
	cout << endl;

	cout << "Duyet theo thu tu giua: ";
	duyetGiua(root);
	cout << endl;

	return 0;
}
