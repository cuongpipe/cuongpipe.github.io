#include <iostream>
#include <vector>
#include <queue>
using namespace std;

struct Edge {
    int adjVertex;  // Dinh ke
    float weight;   // Trong so 
};

typedef vector<vector<Edge>> Graph;

// Ham BFS tim duong di ngan nhat tu sinh vien a den b
bool PathBFS(const Graph& graph, int a, int b, vector<int>& parent) {
    int n = graph.size();
    vector<bool> visited(n, false);
    queue<int> q;
    
    visited[a] = true;
    parent[a] = -1;
    q.push(a);

    while (!q.empty()) {
        int curr = q.front();
        q.pop();

        // Duyet cac dinh ke
        for (const Edge& e : graph[curr]) {
            if (!visited[e.adjVertex]) {
                visited[e.adjVertex] = true;
                parent[e.adjVertex] = curr;
                if (e.adjVertex == b) return true;
                q.push(e.adjVertex);
            }
        }
    }
    return false;  // Khong tim thay duong di
}

// Ham in duong di tu a den b
void printPath(const vector<int>& parent, int a, int b) {
    if (b == -1) {
        cout << "Khong co duong di tu " << a << " den " << b << endl;
        return;
    }

    if (b == a) {
        cout << a << " ";
        return;
    }
    printPath(parent, a, parent[b]);
    cout << b << " ";
}

// Ham kiem tra xem hai sinh vien co the biet so dien thoai cua nhau gian tiep hay khong
void checkPhoneAccess(const Graph& graph, int a, int b) {
    vector<int> parent(graph.size(), -1);
    if (PathBFS(graph, a, b, parent)) {
        cout << "Sinh vien " << a << " co the biet so dien thoai cua sinh vien " << b << " qua cac sinh vien khac. " << endl;
        cout << "Sinh vien " << a << " can hoi qua cac sinh vien theo thu tu: ";
        printPath(parent, a, b);
        cout << endl;
    } else {
        cout << "Khong co duong di giua sinh vien " << a << " va " << b << endl;
    }
}

// Ham kiem tra tinh lien thong cua do thi (N sinh vien co the biet so dien thoai cua nhau)
bool isConnected(const Graph& graph) {
    int n = graph.size();
    vector<bool> visited(n, false);

    // Dung DFS hoac BFS tu dinh 0
    queue<int> q;
    q.push(0);
    visited[0] = true;

    while (!q.empty()) {
        int curr = q.front();
        q.pop();
        for (const Edge& e : graph[curr]) {
            if (!visited[e.adjVertex]) {
                visited[e.adjVertex] = true;
                q.push(e.adjVertex);
            }
        }
    }

    // Kiem tra xem tat ca cac dinh da duoc tham
    for (bool v : visited) {
        if (!v) return false;  // Neu co dinh chua duoc tham, do thi khong lien thong
    }
    return true;  // Neu tat ca cac dinh deu duoc tham, do thi lien thong
}

int main() {
    int n, m;
    cout << "Nhap so luong sinh vien (dinh): ";
    cin >> n;
    cout << "Nhap so luong moi quan he (canh): ";
    cin >> m;

    Graph graph(n);  // Do thi voi n dinh

    // Nhap moi quan he giua sinh vien
    cout << "Nhap cac moi quan he giua sinh vien (a b): " << endl;
    for (int i = 0; i < m; i++) {
        int a, b;
        cin >> a >> b;
        graph[a].push_back(Edge{b, 0});  // Sinh vien a biet so dien thoai cua sinh vien b
        graph[b].push_back(Edge{a, 0});  // Sinh vien b biet so dien thoai cua sinh vien a (vi la do thi vo huong)
    }

    // Kiem tra xem sinh vien 0 co the biet so dien thoai cua sinh vien 4 khong
    checkPhoneAccess(graph, 0, 4);

    // Kiem tra xem do thi co lien thong khong
    if (isConnected(graph)) {
        cout << "Cac sinh vien deu co the biet so dien thoai cua nhau." << endl;
    } else {
        cout << "Khong phai tat ca cac sinh vien deu co the biet so dien thoai cua nhau." << endl;
    }

    return 0;
}
