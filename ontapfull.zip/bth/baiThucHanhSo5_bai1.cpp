#include <bits/stdc++.h>
using namespace std;

struct person {
	string ten;
	int namsinh;
};
struct caynp {
	person data;
	caynp *left, *right;
};
//a) tao cay
caynp* taoNode(person a, caynp* left, caynp* right) {
	return new caynp{a, left, right};
}


caynp* taocaynp() {
	caynp *n1, *n2, *n3, *n4, *n5, *n6;

	n1 = taoNode({"Nguyen D", 1960}, nullptr, nullptr);
	n2 = taoNode({"Nguyen B", 1930}, nullptr, n1); 

	n3 = taoNode({"Nguyen E", 1965}, nullptr, nullptr);
	n4 = taoNode({"Nguyen F", 1970}, nullptr, nullptr);
	n5 = taoNode({"Nguyen C", 1935}, n3, n4);

	n6 = taoNode({"Nguyen A", 1900}, n2, n5);
	return n6;

}

caynp* taocaynp2() {
	caynp *n1, *n2, *n3, *n4, *n5, *n6;

	n1 = taoNode({"Nguyen D", 1960}, nullptr, nullptr);
	n2 = taoNode({"Nguyen B", 1930}, nullptr, n1); 

	n3 = taoNode({"Nguyen E", 1965}, nullptr, nullptr);
	n4 = taoNode({"Nguyen F", 1970}, nullptr, nullptr);
	n5 = taoNode({"Nguyen C", 1935}, n3, n4);

	n6 = taoNode({"Nguyen A", 1900}, n2, n5);
	return n6;
}



// b in cay
void incaynp(caynp * root) {
	// duyet truoc root -> left -> right
	if(root) {
		cout << root->data.ten << " " << root->data.namsinh << endl;

		incaynp(root->left);// duyet root -> left
		incaynp(root->right);// duyet root -> right
	}
}

//c dem so nguoi trong cay
int demnguoi(caynp * root) {
	if(!root) return 0;
	return 1 + demnguoi(root->left) + demnguoi(root->right);
}

//d tinh so the he cua cay
int demthehe(caynp *root) {
	if(!root) return 0;
	return 1 + max(demthehe(root->left), demthehe(root->right));
}

//e dem so nguoi sinh truoc nam x
int demnguoisinhtruocnamx(caynp *root, int x) {
	if(!root) return 0;
	else {
		if(root->data.namsinh < x) {
			return 1 + demnguoisinhtruocnamx(root->left, x) + demnguoisinhtruocnamx(root->right, x);
		} else return 0;
	}
}
//f tim 1 nguoi theo ho ten
caynp* timnguoi(caynp* root, string ten) {
	if (!root) return nullptr;
	if (root->data.ten == ten) return root;
	caynp* left = timnguoi(root->left, ten);
	if (left) return left;
	return timnguoi(root->right, ten);
}
//g kiem tra nguoi cname co phai con nguoi ten pname khong ?
bool  cnamecophaiconcname(caynp *root, string cname, string pname) {
	caynp* cha;
	cha = timnguoi(root, pname);
	if(!cha) return false;
	else {
		return (cha->left && cha->left->data.ten==cname) or (cha->right && cha->right->data.ten==cname);
	}

}

//h) cho biet nguoi ten x thuoc the he thu may trong cay
int thehecuax(caynp* root, string ten) {
	if (!root) return 0;
	if (root->data.ten == ten) return 1;
	int left = thehecuax(root->left, ten);
	if (left) return left + 1;
	int right = thehecuax(root->right, ten);
	if (right) return right + 1;

	return 0;
}

//i)kiem tra nguoi ten y co phai con chau cua nguoi ten x khong
bool conchau(caynp* root, string x, string y) {
	caynp* conchau = timnguoi(root, x);
	if (!conchau) return false;
	return timnguoi(conchau, y) != nullptr;
}

//j) liet ke tat ca con chau cua nguoi ten x
void lietkeconchau(caynp* root, string x) {
	caynp* conchau = timnguoi(root, x);
	if (!conchau) return;
	incaynp(conchau->left);
	incaynp(conchau->right);
}

//k)thay nguoi ten x bang moi nguoi khac trong cay gia pha

void thaynguoi(caynp* root, string x, person nguoithayx) {
	caynp* timx = timnguoi(root, x);
	caynp* timnguoithayx = timnguoi(root, nguoithayx.ten);
	if (!timx ) {
		cout << "Khong tim thay nguoi ten " << x << endl;
		return;
	}
	person tmp = timx->data;  
	timx->data = nguoithayx;   
	timnguoithayx->data = tmp;  
	cout << "Da thay nguoi ten " << x << " bang nguoi ten " << nguoithayx.ten << endl;
}



//l)kiem tra hai nguoi ten x, y có phai anh em khong
bool xyanhem(caynp* root, string x, string y) {
	if (!root) return false;
	if (root->left && root->right) {
		if ((root->left->data.ten == x && root->right->data.ten == y) or (root->left->data.ten == y && root->right->data.ten == x))
			return true;
	}
	return xyanhem(root->left, x, y) or xyanhem(root->right, x, y);
}


//m) liet ke nhung nguoi trong cay thuoc the he thu k
void lietkethehek(caynp* root, int k) {
	if (!root) return;
	if (k == 1) {
		cout << root->data.ten << " " << root->data.namsinh << endl;
		return;
	}
	lietkethehek(root->left, k - 1);
	lietkethehek(root->right, k - 1);
}

//n)kiem tra hai cay gia pha co giong nhau khong
bool sosanhcay(caynp* root1, caynp* root2) {
	if (!root1 && !root2) return true;
	if (!root1 or !root2) return false;
	return (root1->data.ten == root2->data.ten && root1->data.namsinh == root2->data.namsinh && sosanhcay(root1->left, root2->left) && sosanhcay(root1->right, root2->right));
}



//o)them nguoi ng vao con cua nguoi ten x. neu nguoi ten x da du con thi khong them
//Khai báo kiểu dữ liệu:
bool themcon(caynp* root, string x, person ng) {
	caynp* parent = timnguoi(root, x);
	if (!parent or (parent->left && parent->right)) return false;
	if (!parent->left) parent->left = taoNode(ng, nullptr, nullptr);
	else parent->right = taoNode(ng, nullptr, nullptr);
	return true;
}


int main() {
	caynp *root, *kq;
	root = taocaynp();
	incaynp(root);
	cout << "so nguoi co trong cay la: " << demnguoi(root) << endl;
	cout << "so the he trong cay la: " << demthehe(root) << endl;
	int x = 1960;
	cout << "so nguoi sinh truoc nam "<< x << " la: " << demnguoisinhtruocnamx(root, x) << endl;
	string ten = "Nguyen B";
	kq = timnguoi(root, ten);
	if (kq) {
		cout <<"tim thay nguoi ten "<< kq->data.ten <<" nam sinh "<<kq->data.namsinh<< endl;
	} else
		cout << "khong thay nguoi ho ten "<< ten << endl;

	string cname = "Nguyen B", pname = "Nguyen A";
	bool kt2 = cnamecophaiconcname(root, cname, pname);
	if (kt2)
		cout << cname << " la con cua nguoi ten " << pname << endl;
	else
		cout << cname << " khong phai con nguoi ten " << pname << endl;

	cout <<"the he cua " << ten << " la: " << thehecuax(root, ten) << endl;


	string x1 = "Nguyen A", y = "Nguyen E";
	if(conchau(root, x1, y)) {
		cout << y <<  " la con chau cua " << x1 << endl;
	} else cout << y <<  " khong phai la con chau cua " << x1 << endl;


	cout << "liet ke con chau cua " << x1 << endl;
	lietkeconchau(root, x1);


	string x2 = "Nguyen B";
	person nguoithayx = {"Nguyen C", 1935};

	thaynguoi(root, x2, nguoithayx);



	string x3 = "Nguyen B", y3 = "Nguyen C";
	if (xyanhem(root, x3, y3)) {
		cout << x3 << " va " << y3 << " la anh em" << endl;
	} else {
		cout << x3 << " va " << y3 << " khong phai la anh em" << endl;
	}
	int k = 2;
	cout << "nhung nguoi thuoc the he " << k << endl;
	lietkethehek(root, k);


	caynp *root2 = taocaynp2();
	cout << "cay gia pha 1:" << endl;
	incaynp(root);
	cout << "cay gia pha 2:" << endl;
	incaynp(root2);



	if (sosanhcay(root, root2)) {
		cout << "hai cay gia pha giong nhau" << endl;
	} else {
		cout << "hai cay gia pha khong giong nhau" << endl;
	}

	string x4 = "Nguyen D";
	person conmoi = {"Nguyen Y", 2010};
	if (themcon(root, x4, conmoi))
		cout << "da them " << conmoi.ten << " vao cay gia pha" << endl;
	else
		cout << "khong the them " << conmoi.ten << " vi da "<< x3 << " du 2 con" << endl;
	cout <<"cay sau khi them "<< conmoi.ten << endl;
	incaynp(root);

	return 0;
}
