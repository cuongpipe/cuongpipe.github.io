#include <iostream>
#include <stack>

using namespace std;

int mucUuTien(char c) {
    if (c == '+' || c == '-') return 1;
    else if (c == '*' || c == '/') return 2;
    else return -1;
}

string chuyenDoi(string s) {
    string ketQua;
    stack<char> st;
    
    for (char c : s) {
        if (isalnum(c)) {  // Nếu là toán hạng (số hoặc chữ cái)
            ketQua += c;
        } 
        else if (c == '(') {
            st.push(c);
        } 
        else if (c == ')') {
            while (!st.empty() && st.top() != '(') {
                ketQua += st.top();
                st.pop();
            }
            if (!st.empty()) st.pop();  // Loại bỏ dấu '(' khỏi stack
        } 
        else {  // Nếu là toán tử
            while (!st.empty() && mucUuTien(st.top()) >= mucUuTien(c) && st.top() != '(') {
                ketQua += st.top();
                st.pop();
            }
            st.push(c);
        }
    }

    // Pop các phần tử còn lại trong stack
    while (!st.empty()) {
        ketQua += st.top();
        st.pop();
    }

    return ketQua;
}

int main() {
    int n;
    ///vd 
//3
//A+B
//(A+B)*C
//A+B*C-(D/E)

    cin >> n;
    cin.ignore();  // Loại bỏ ký tự xuống dòng sau khi nhập n

    while (n--) {
        string s;
        getline(cin, s);  // Nhập cả dòng để tránh lỗi nhập thiếu
        cout <<"ket-qua: "<<chuyenDoi(s) << endl;
    }

    return 0;
}

///vd 
//3
//A+B
//(A+B)*C
//A+B*C-(D/E)

//kq: 
//3
//A+B
//ket-qua: AB+
//(A+B)*C
//ket-qua: AB+C*
//A+B*C-(D/E)
//ket-qua: ABC*+DE/-


