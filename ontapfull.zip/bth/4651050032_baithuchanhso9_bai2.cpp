#include <iostream>
#include <fstream>
#include <cstring>
#include <queue>
#include <vector>
using namespace std;

#define MAX_VERTICES 100

struct AdjMatrixGraph {
	int numVertices;
	int adjMatrix[MAX_VERTICES][MAX_VERTICES];
};

void readGraphFromFile(string fileName, AdjMatrixGraph &graph) {
	ifstream file(fileName);
	file >> graph.numVertices;
	for (int i = 0; i < graph.numVertices; i++)
		for (int j = 0; j < graph.numVertices; j++)
			file >> graph.adjMatrix[i][j];
	file.close();
}

void DFS(const AdjMatrixGraph& graph, int vertex, bool visited[]) {
	visited[vertex] = true;
	for (int i = 0; i < graph.numVertices; i++) {
		if (graph.adjMatrix[vertex][i] != 0 && !visited[i])
			DFS(graph, i, visited);
	}
}
// a) x biết trực tiếp y?
bool knowsDirectly(AdjMatrixGraph g, int x, int y) {
	return g.adjMatrix[x][y] != 0;
}

//b) x biết trực tiếp hoặc gián tiếp z?
bool knowsIndirectly(AdjMatrixGraph g, int x, int z) {
	bool visited[MAX_VERTICES];
	memset(visited, false, sizeof(visited));
	DFS(g, x, visited);
	return visited[z];
}


//c) x có thể biết hết số điện thoại cả lớp?
bool knowsAll(AdjMatrixGraph g, int x) {
	bool visited[MAX_VERTICES];
	memset(visited, false, sizeof(visited));
	DFS(g, x, visited);
	for (int i = 0; i < g.numVertices; i++) {
		if (!visited[i])
			return false;
	}
	return true;
}


//d) Những sinh viên không ai biết số của họ
void studentsNoOneKnows(AdjMatrixGraph g) {
	cout << "Sinh vien khong ai biet so: ";
	for (int i = 0; i < g.numVertices; i++) {
		bool known = false;
		for (int j = 0; j < g.numVertices; j++) {
			if (g.adjMatrix[j][i] != 0) {
				known = true;
				break;
			}
		}
		if (!known)
			cout << i << " ";
	}
	cout << endl;
}

//e) Có sinh viên nào biết hết số điện thoại không?
void studentKnowsAll(AdjMatrixGraph g) {
	for (int i = 0; i < g.numVertices; i++) {
		if (knowsAll(g, i)) {
			cout << "Sinh vien " << i << " biet so cua tat ca sinh vien." << endl;
			return;
		}
	}
	cout << "Khong co sinh vien nao biet het so." << endl;
}


// f) Tìm tập nhỏ nhất sinh viên biết hết số điện thoại cả lớp
void minimalCoveringSet(AdjMatrixGraph g) {
	bool visited[MAX_VERTICES];
	memset(visited, false, sizeof(visited));

	vector<int> coverSet;

	for (int i = 0; i < g.numVertices; i++) {
		if (!visited[i]) {
			// thêm i vào tập hợp
			coverSet.push_back(i);
			// duyệt DFS từ i để đánh dấu các đỉnh biết được
			DFS(g, i, visited);
		}
	}

	cout << "Tap sinh vien nho nhat biet het so ca lop: ";
	for (int id : coverSet)
		cout << id << " ";
	cout << endl;
}

int main() {
	AdjMatrixGraph g;
	readGraphFromFile("GraphPhone.txt", g);

	int x = 0, y = 2, z = 4;

	if (knowsDirectly(g, x, y)) {
		cout << "Sinh vien " << x << " biet truc tiep so cua sinh vien " << y << endl;
	} 
	else {
		cout << "Sinh vien " << x << " khong biet truc tiep so cua sinh vien " << y << endl;
	}

	if (knowsIndirectly(g, x, z)) {
		cout << "Sinh vien " << x << " biet truc tiep hoac gian tiep so cua sinh vien " << z << endl;
	} 
	else {
		cout << "Sinh vien " << x << " khong biet duoc so cua sinh vien " << z << endl;
	}

	if (knowsAll(g, x)) {
		cout << "Sinh vien " << x << " biet so cua tat ca sinh vien trong lop" << endl;
	} 
	else {
		cout << "Sinh vien " << x << " khong biet het so cua tat ca sinh vien trong lop" << endl;
	}



	studentsNoOneKnows(g);
	studentKnowsAll(g);
	minimalCoveringSet(g);

	return 0;
}

