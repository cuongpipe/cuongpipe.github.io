//CÂY NHỊ PHÂN: 
//Mỗi nút có:
//Bên trái chứa các nút có giá trị nhỏ hơn
//Bên phải chứa các nút có giá trị lớn hơn

#include <bits/stdc++.h>
#include <string>
using namespace std;

struct person {
	string name;
	int yearOfBirth;
};
struct BFT {
	person data;
	BFT* left, * right;
};
//a) tao cay

void insert(BFT* &root, person p) {
	if (root == nullptr) {
		root = new BFT;
		root->data = p;
		root->left = nullptr;
		root->right = nullptr;
	} else {
		if(root->data.yearOfBirth > p.yearOfBirth)
			insert(root->left, p);
		else if(root->data.yearOfBirth < p.yearOfBirth)
			insert(root->right, p);
	}
}


//// b in cay
void incaynp(BFT* root) {
	// duyet truoc root -> left -> right
	if(root) {
		cout << root->data.name << " " << root->data.yearOfBirth << endl;

		incaynp(root->left);// duyet root -> left
		incaynp(root->right);// duyet root -> right
	}
}

// in cay can phai
void inCay(BFT* root, int space = 0) {
	if (root == nullptr) return;

	// In node hiện tại trước
	cout << string(space, ' ') << root->data.name << " (" << root->data.yearOfBirth << ")" << endl;

	// In nhánh phải trước
	inCay(root->right, space + 4);

	// Sau đó in nhánh trái
	inCay(root->left, space + 4);
}

//c dem so nguoi trong cay
int demnguoi(BFT* root) {
	if(!root) return 0;
	return 1 + demnguoi(root->left) + demnguoi(root->right);
}


//Tính tổng tất cả giá trị trong các node
//→ Thích hợp khi root->data là kiểu in
//vd: tính tổng điểm trong cây
//ở đây tính tổng năm sinh
int sumTree(BFT* root) {
	if (root == nullptr)
		return 0;
	int leftSum = sumTree(root->left); // Tổng bên trái
	int rightSum = sumTree(root->right); // Tổng bên phải
	return root->data.yearOfBirth + leftSum + rightSum; // Cộng tổng 3 phần
}


//d tinh so the he cua cay
int demthehe(BFT* root) {
	if(!root) return 0;
	return 1 + max(demthehe(root->left), demthehe(root->right));
}

//e dem so nguoi sinh truoc nam x
int demnguoisinhtruocnamx(BFT* root, int x) {
	if (!root) return 0;

	int dem = 0;
	if (root->data.yearOfBirth < x)
		dem = 1;

	return dem + demnguoisinhtruocnamx(root->left, x) + demnguoisinhtruocnamx(root->right, x);
}



bool timnguoi(BFT* root, string x) {
	if(root == nullptr) {
		return false;
	} else {


		if (root->data.name == x) return true;

		else {
			if(root->data.name > x) {
				return timnguoi(root->left, x);
			} else return timnguoi(root->right, x);
		}

	}
}

//h) cho biet nguoi name x thuoc the he thu may trong cay

int thehecuax(BFT *root, string x, int k) {
	if(!root)
		return -1;
	else {
		if(root->data.name == x)
			return k;
		int theheXLeft = thehecuax(root->left, x, k+1);
		if(theheXLeft != -1) {
			return theheXLeft;
		} else {
			return thehecuax(root->right, x, k+1);
		}
	}
}

//l)kiem tra hai nguoi name x, y có phai anh em khong
bool xyanhem(BFT* root, string x, string y) {
	if (!root) return false;
	if (root->left && root->right) {
		if ((root->left->data.name == x && root->right->data.name == y) or (root->left->data.name == y && root->right->data.name == x))
			return true;
	}
	return xyanhem(root->left, x, y) or xyanhem(root->right, x, y);
}


//m) liet ke nhung nguoi trong cay thuoc the he thu k
void lietkethehek(BFT* root, int k) {
	if (!root) return;
	if (k == 1) {
		cout << root->data.name << " " << root->data.yearOfBirth << endl;
		return;
	}
	lietkethehek(root->left, k - 1);
	lietkethehek(root->right, k - 1);
}

//n)kiem tra hai cay gia pha co giong nhau khong
bool sosanhcay(BFT* root1, BFT* root2) {
	if (!root1 && !root2) return true;
	if (!root1 or !root2) return false;
	return (root1->data.name == root2->data.name && root1->data.yearOfBirth == root2->data.yearOfBirth && sosanhcay(root1->left, root2->left) && sosanhcay(root1->right, root2->right));
}



// Liệt kê người bắt đầu bằng tiền tố x, tìm người họ x
void lietKeTheoDau(BFT* root, const string& x) {
	if (!root) return;
	if (root->data.name.substr(0, x.size()) == x)
		cout << "  "<< root->data.name << ": " << root->data.yearOfBirth << endl;
	lietKeTheoDau(root->left, x);
	lietKeTheoDau(root->right, x);
}

// liệt kê các số kết thúc bằng tiền tố x, tìm người tên x
void lietKeTheocuoi(BFT* root, const string x) {
	if (!root) return;

	const string name = root->data.name;
	if (name.size() >= x.size() && name.substr(name.size() - x.size()) == x)
		cout << "  " << name << ": " << root->data.yearOfBirth << endl;

	lietKeTheocuoi(root->left, x);
	lietKeTheocuoi(root->right, x);
}


//e dem so nguoi sinh truoc sau x
int demnguoisinhsaunamx(BFT* root, int x) {
	if (!root) return 0;

	int dem = 0;
	if (root->data.yearOfBirth > x)
		dem = 1;

	return dem + demnguoisinhsaunamx(root->left, x) + demnguoisinhsaunamx(root->right, x);
}


//liet ke nhung nguoi sinh truoc nam x
void lietkenguoisinhtruocnamx(BFT* root, int x) {
	if (!root) return;

	if (root->data.yearOfBirth < x) {
		cout << root->data.name << " (" << root->data.yearOfBirth << ")" << endl;
	}

	lietkenguoisinhtruocnamx(root->left, x);
	lietkenguoisinhtruocnamx(root->right, x);
}


//liet ke nhung nguoi sinh sau nam x
void lietkenguoisinhsaunamx(BFT* root, int x) {
	if (!root) return;

	if (root->data.yearOfBirth > x) {
		cout << root->data.name << " (" << root->data.yearOfBirth << ")" << endl;
	}

	lietkenguoisinhsaunamx(root->left, x);
	lietkenguoisinhsaunamx(root->right, x);
}

//tim nguoi theo nam x
BFT* timnguoitheonamx(BFT* root, int x) {
	if (!root) return nullptr;
	if (root->data.yearOfBirth == x) return root;
	BFT* left = timnguoitheonamx(root->left, x);
	if (left) return left;
	return timnguoitheonamx(root->right, x);
}

//tim nho nhat
int min(BFT *root) {
	if (!root) return -1; // hoặc throw lỗi nếu cây rỗng

	if (!root->left)
		return root->data.yearOfBirth;
	else
		return min(root->left);
}

//tim lon nhat
int max(BFT *root) {
	if (!root) return -1; // hoặc throw lỗi nếu cây rỗng

	if (!root->right)
		return root->data.yearOfBirth;
	else
		return max(root->right);
}


//duyệt trước
void preOrder(BFT *root) {
	if (root != nullptr) {
// xu ly nut tham tai day
		cout << root->data.name << " ";
		preOrder(root->left);
		preOrder(root->right);
	}
}

//duyet giua
void inOrder(BFT *root) {
	if (root != nullptr) {
		inOrder(root->left);
		cout << root->data.name << " ";
		inOrder(root->right);
	}
}

//duyet sau
void postOrder(BFT *root) {
	if (root != nullptr) {
		postOrder(root->left);
		postOrder(root->right);
		cout << root->data.name << " ";
	}
}

//xóa node này
void deleteNode(BFT* &root, string x) {
    if (!root) return;

    if (x < root->data.name) {
        deleteNode(root->left, x);
    } else if (x > root->data.name) {
        deleteNode(root->right, x);
    } else {
        // Tìm thấy node cần xóa
        if (!root->left && !root->right) {
            delete root;
            root = nullptr;
        } else if (!root->left) {
            BFT* temp = root;
            root = root->right;
            delete temp;
        } else if (!root->right) {
            BFT* temp = root;
            root = root->left;
            delete temp;
        } else {
            // Có cả hai con
            // Tìm node nhỏ nhất ở cây con phải
            BFT* minNode = root->right;
            while (minNode->left)
                minNode = minNode->left;

            // Copy dữ liệu node nhỏ nhất lên root
            root->data = minNode->data;

            // Xóa node nhỏ nhất khỏi cây con phải
            deleteNode(root->right, minNode->data.name);
        }
    }
}


// chèn 

//điều kiện chạy là cây BST theo name không phải theo năm sinh 
BFT* findByNameBST(BFT* root, const string& name) {
	if (!root) return nullptr;
	if (root->data.name == name) return root;
	else if (name < root->data.name)
		return findByNameBST(root->left, name);
	else
		return findByNameBST(root->right, name);
}



bool insertChildToBFT(BFT* root, const string& parentName, person child) {
	BFT* parent = findByNameBST(root, parentName);
	if (!parent) {
		cout << "khong tim thay nguoi cha nao ten: " << parentName << endl;
		return false;
	}

	BFT* newNode = new BFT{child, nullptr, nullptr};

	if (!parent->left && !parent->right) {
		// Chưa có con nào
		parent->left = newNode;
		return true;
	} else if (parent->left && !parent->right) {
		// Đã có con trái, thêm con phải
		if (child.yearOfBirth < parent->left->data.yearOfBirth) {
			// newNode nhỏ hơn → chuyển con trái sang phải, chèn newNode sang trái
			parent->right = parent->left;
			parent->left = newNode;
		} else {
			parent->right = newNode;
		}
		return true;
	} else {
		cout << "Nguoi ten " << parentName << " da du 2 con." << endl;
		return false;
	}
}

int main() {
	//trong cây nhị phân bên phải lớn hơn bên trái !
	//đây là so theo bảng mã asci
	BFT* root = nullptr;
//	insert(root, {"Duy", 1990});
//	
//	//"An" < "Duy" → An bên trái Duy	
//	insert(root, {"An", 1965});
//
//	//"Khoa" > "Duy" → Khoa bên phải Duy
//	insert(root, {"Khoa", 1985});
//
//	//"Binh" > "An" → Binh bên phải An
//	insert(root, {"Binh", 1975});
//
//	//"Hoang" < "Khoa" → Hoang bên trái Khoa
//	insert(root, {"Hoang", 2018});
//
//	//"Lan" > "Hoang" → Lan bên phải Hoang
//	insert(root, {"Lan", 1995});
//
//	//"Minh" > "Lan" → Minh bên phải Lan
//	insert(root, {"Minh", 2000});
  
  
  //cách này là insert theo năm sinh : năm sinh bên trái luôn nhỏ hơn bên phải  
	//chua co con tao => duy là root
	insert(root, {"Duy", 1990});
	
	//them lan mà 1995 lớn hơn 1990 => con bên phải duy
	insert(root, {"Lan", 1995});
	
	//them minh mà 2000 lớn hơn 1995 => con bên phải lan
	insert(root, {"Minh", 2000});
	
	//them hoang mà 2018 lớn hơn 2000 => con bên phải minh
	insert(root, {"Hoang", 2018});
	
	//them An mà 1965 bé hơn cả 2018 2000 1995 1990 => vì cuối cùng là 1990 => con bên trái của dUY  
	insert(root, {"An", 1965});
	
	//THEM binh mà 1975 lớn hơn 1965 => sang phải An
	insert(root, {"Binh", 1975});
	
	//them khoa mà 1985 lớn hơn 1975 => sang phải Binh
	insert(root, {"Khoa", 1985});


	//in cai cay nhi phan 1 ra xem thu
	cout <<"In cay nhi phan 1" << endl;
	incaynp(root);
	cout <<"In cay cai cay gia pha 1 nao:" << endl;
	inCay(root);
	cout << endl;

	//tinh so nguoi co trong cay, dem
	cout << "so nguoi co trong cay la: " << demnguoi(root) << endl;
	cout << endl;
	
	cout <<"Sum nam sinh ca cay " << sumTree(root) << endl;

	//tinh so the he cua cay, dem
	cout << "So the he trong cay la: " << demthehe(root) << endl;
	cout << endl;

	//tinh So nguoi sinh truoc nam x, dem
	int x = 1980;
	cout << "So nguoi sinh truoc nam "<< x << " la: " << demnguoisinhtruocnamx(root, x) << endl;
	cout << endl;


	//tim nguoi name x
	string namex = "An";
	if (timnguoi(root, namex)) {
		cout << "Tim thay nguoi name "<< namex<<" trong cay nhi phan 1" << endl;
	} else
		cout << "Khong thay nguoi name "<< namex << " trong cay nhi phan 1" << endl;
	cout << endl;



	//kiem tra cname co phai la con pname khum
	string cname = "Lan", pname = "Khoa";


	//the he nguoi namex2
	string namex2 = "Duy";
	int kk = 1;
	cout <<"The he cua " << namex2 << " la: " << thehecuax(root, namex2, kk) << endl;
	cout << endl;

	//kiem tra y phai con chay x1 khum
	string x1 = "Duy", y = "Lan";



	//liệt kê con cháu của x10
	string x10 = "Khoa";
	cout << "Liet ke con chau cua " << x10 << endl;


	//kiem tra x3 va y3 co phai anh em cay khe
	string x3 = "khoa", y3 = "an";
	if (xyanhem(root, x3, y3)) {
		cout << x3 << " va " << y3 << " La anh em" << endl;
	} else {
		cout << x3 << " va " << y3 << " Khong phai la anh em" << endl;
	}
	cout << endl;


	//liet ke nhung nguoi thuoc the he k
	int k = 2;
	cout << "Nhung nguoi thuoc the he " << k << endl;
	lietkethehek(root, k);
	cout << endl;


	//in cay ra pha 1
	cout << "Cay gia pha 1:" << endl;
	incaynp(root);
	cout <<"In cay cai cay gia pha 1 nao:" << endl;
	
	//in cây theo kiểu nhanh phải trước rồi đến trái
	inCay(root);
	cout << endl;



//	//in cay ra pha 2
	BFT* root2 = nullptr;
//	insert(root2, {"Duy", 1990});
//	//"An" < "Duy" → An bên trái Duy
//	insert(root2, {"An", 1965});
//
//	//"Khoa" > "Duy" → Khoa bên phải Duy
//	insert(root2, {"Khoa", 1985});
//
//	//"Binh" > "An" → Binh bên phải An
//	insert(root2, {"Binh", 1975});
//
//	//"Hoang" < "Khoa" → Hoang bên trái Khoa
//	insert(root2, {"Hoang", 2018});
//
//	//"Lan" > "Hoang" → Lan bên phải Hoang
//	insert(root2, {"Lan", 1995});
//
//	//"Minh" > "Lan" → Minh bên phải Lan
//	insert(root2, {"Minh", 2000});


  	//cách này là insert theo năm sinh : năm sinh bên trái luôn nhỏ hơn bên phải  
	//chua co con tao => duy là root2
	insert(root2, {"Duy", 1990});
	
	//them lan mà 1995 lớn hơn 1990 => con bên phải duy
	insert(root2, {"Lan", 1995});
	
	//them minh mà 2000 lớn hơn 1995 => con bên phải lan
	insert(root2, {"Minh", 2000});
	
	//them hoang mà 2018 lớn hơn 2000 => con bên phải minh
	insert(root2, {"Hoang", 2018});
	
	//them An mà 1965 bé hơn cả 2018 2000 1995 1990 => vì cuối cùng là 1990 => con bên trái của dUY  
	insert(root2, {"An", 1965});
	
	//THEM binh mà 1975 lớn hơn 1965 => sang phải An
	insert(root2, {"Binh", 1975});
	
	//them khoa mà 1985 lớn hơn 1975 => sang phải Binh
	insert(root2, {"Khoa", 1985});


	cout << "Cay gia pha 2:" << endl;
	incaynp(root2);
	cout <<"In cay cai cay gia pha 2 nao:" << endl;
	inCay(root2);
	cout << endl;

	//so sanh 2 cay gia pha
	if (sosanhcay(root, root2)) {
		cout << "Hai cay gia pha giong nhau" << endl;
	} else {
		cout << "Hai cay gia pha khong giong nhau" << endl;
	}
	cout << endl;

	//tim người họ Nguyễn
	string  x5 = "A";
	cout << "Nguoi co ten bat dau bang " << x5 << " la" << endl;
	lietKeTheoDau(root, x5);
	cout << endl;

	//tim người tên A
	string x6 = "n";
	cout << "Nguoi co name ket thuc bang " << x6 << " la" << endl;
	lietKeTheocuoi(root, x6);
	cout << endl;


	//tinh so nguoi sinh nam x, dem
	int xs = 1985;
	cout << "So nguoi sinh sau nam "<< xs << " la: " << demnguoisinhsaunamx(root, xs) << endl;
	cout << endl;


	//liet ke tat ca nguoi sinh truoc nam x, dem
	cout << "liet ke nguoi sinh truoc nam " << xs << endl;
	lietkenguoisinhtruocnamx(root, xs);
	cout << endl;

	//liet ke tat ca nguoi sinh sau nam x, dem
	cout << "liet ke nguoi sinh sau nam " << xs << endl;
	lietkenguoisinhsaunamx(root, xs);
	cout << endl;


	//tim nguoi sinh nam x, dem
	int xsm = 1980;
	BFT* kqn = timnguoitheonamx(root, xsm);
	if (kqn) {
		cout << "Tim thay nguoi name "<< kqn->data.name <<" nam sinh "<< kqn->data.yearOfBirth << " trong cay nhi phan 1" << endl;
	} else
		cout << "Khong thay nguoi sinh nam "<< xsm<< " trong cay nhi phan 1" << endl;
	cout << endl;


	int xsmp = min(root);
	cout << "Nam sinh gia nhat cay nhi phan 1 la " << xsmp << endl;
	BFT* kqnn = timnguoitheonamx(root, xsmp);
	if (kqnn) {
		cout << "Nguoi gia nhat "<< kqnn->data.name <<" nam sinh "<< kqnn->data.yearOfBirth << " trong cay nhi phan 1" << endl;
	}



	int xsmpm = max(root);
	cout << "Nam sinh tre nhat cay nhi phan 1 la " << xsmpm << endl;
	BFT* kqnnq = timnguoitheonamx(root, xsmpm);
	if (kqnnq) {
		cout << "Nguoi tre nhat "<< kqnnq->data.name <<" nam sinh "<< kqnnq->data.yearOfBirth << " trong cay nhi phan 1" << endl;
	}




	cout << "Duyet truoc:" << endl;
	preOrder(root);
	cout << endl;

	cout << "Duyet giua:" << endl;
	inOrder(root);
	cout << endl;



	cout << "Duyet sau:" << endl;
	postOrder(root);
	cout << endl;


	string xxs = "Binh";
	cout << "Da xoa nguoi ten " << xxs <<" khoi cay" << endl;
	deleteNode(root, xxs);
	cout <<"In cay cai cay gia pha 1 nao:" << endl;
	inCay(root);
	cout << endl;
		
	insertChildToBFT(root, "Hoang", {"Hoa", 1890});
	cout <<"In cay cai cay gia pha 1 nao:" << endl;
	inCay(root);
	cout << endl;

	return 0;
}



